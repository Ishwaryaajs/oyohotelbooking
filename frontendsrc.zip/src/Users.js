import {React,useState, useEffect,useRef } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'
export function PostUsers()
{
  const [users, setusers] = useState([]);
  let navigate = useNavigate();
  

    const getUser = async () => {
      try {
        const response = await fetch('https://localhost:44328/api/User/GetUser');
        const data = await response.json();
        setusers(data);
        console.log(data);
      } catch (error) {
        console.log(error);
      }
    };
    useEffect(()=>
    {   getUser();
    }, [])
    function OnDelete(id) {
      axios.delete("https://localhost:44328/api/User/Delete/" + id)
        .then((response) => {
          alert(' user deleted succesfully');
          getUser();
  
        })
        .catch((err) => { alert('Failed to delete user') })
    }
  
    function OnEdit(item) {
      navigate('/AddUserDetail', { state: item });
  
  
  
    }
 

  return (
    
      <table border='2' className="table table-light w-75  m-4">
        <span className="border border-dark"></span>
        <thead className="table-success" align="center">
        <tr>
            <th colSpan={5}>User Details</th>
        </tr>
        
        
         <tr>
            <th className='p-1'>userId</th>
            <th className='p-1'>userName</th>
            <th className='p-1'>userEmail</th>
            <th className='p-1'>userPassword</th>
            <th className="p-1">Action</th>
            
            </tr>
            </thead>
            <tbody>
           
           {users.map((item,i)=>
           {
            return <tr key={i} value={item}>
              <td className='p-1'>{item.userId}</td>
              <td className='p-1'>{item.userName}</td>
              <td className='p-1'>{item.userEmail}</td>
              <td className='p-1'>{item.userPassword}</td>
              <td className="p-1">
              <button type="button" onClick={() => { OnDelete(item.userId) }} className="btn btn-outline-danger btn-sm">Delete</button>
<button type="button" onClick={() => { OnEdit(item) }} className="btn btn-outline-success btn-sm">Edit</button>
            
          </td>
            </tr>;
           })}
           
           </tbody>
    
          
   
      </table>
     
  );
}

export function Users()
{
  const OnClick=()=>
  {
    window.location.href="/AddUserDetail";
  }
  return(
    <div>
      
      <button onClick={OnClick} className="btn btn-primary ms-4">Add New User</button>
      <PostUsers/>
    </div>
  );
}
//<th className="p-1">Action</th>
//<button type="button" onClick={() => { OnDelete(item.userId) }} className="btn btn-outline-danger btn-sm">Delete</button>
//<button type="button" onClick={() => { OnEdit(item) }} className="btn btn-outline-success btn-sm">Edit</button>