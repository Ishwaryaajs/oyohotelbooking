import React from "react";
export default function Home()
{
    return(
        <div class="mt-5 pt-5">
            <div
        style={{
          height: '100vh',
          width: '100%',
          overflow: 'hidden',
          background: 'url("images/oyopic.jpg")',
          backgroundSize: 'cover',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <h1
          style={{
            fontSize: '4rem',
            color: 'white',
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            padding: '15px',
            fontWeight: 'bold',
          }}
        >
          Welcome to Hotel Bookings
        </h1>
      </div>
            <div>

            </div>
        </div>
    )
}