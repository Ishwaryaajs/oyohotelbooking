import {React,useState, useEffect,useRef } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'
export function PostHotels()
{
  const [hotels, sethotels] = useState([]);
  let navigate = useNavigate();

    const getHotel = async () => {
      try {
        const response = await fetch('https://localhost:44328/api/Hotel/GetHotels');
        const data = await response.json();
        sethotels(data);
        //console.log(data);
      } catch (error) {
        // console.log(error);
        alert(`failed to load hotels`);
      }
    };
    useEffect(()=>
    {   getHotel();
    }, [])
    function OnDelete(id) {
      axios.delete("https://localhost:44328/api/Hotel/Delete/" + id)
        .then((response) => {
          alert(' Hotel deleted succesfully');
          getHotel();
  
        })
        .catch((err) => { alert('Failed to delete Hotel') })
    }
  
    function OnEdit(k) {
      navigate('/AddHotelDetail', { state: k });
  
  
  
    }
 

  return (
    
      <table border='2' className="table table-light w-75 m-4 ">
        <span className="border border-dark"></span>
        <thead className="table-success" align="center">
        <tr>
            <th colSpan={9}>Hotel Details</th>
        </tr>
        
         <tr>
            <th className="p-1">HotelId</th>
            <th className="p-1">HotelName</th>
            <th className="p-1">HotelAddress</th>
            <th className="p-1">HotelCity</th>
            <th className="p-1">HotelState</th>
            <th className="p-1">HotelCountry</th>
            <th className="p-1">HotelRating</th>
            <th className="p-1">Action</th>
           
            
            </tr> 
            </thead>
            <tbody>
           {hotels.map((k,j)=>
           {
            return <tr className="table-light" key={j} value={k}>
              <td className="p-1">{k.hotelId}</td>
              <td className="p-1">{k.hotelName}</td>
              <td className="p-1">{k.hotelAddress}</td>
              <td className="p-1">{k.hotelCity}</td>
              <td className="p-1">{k.hotelState}</td>
              <td className="p-1">{k.hotelCountry}</td>
              <td className="p-1">{k.hotelRating}</td>
              <td className="p-1 d-flex flex-row">
            <button type="button" onClick={() => { OnDelete(k.hotelId) }} className="btn btn-outline-danger btn-sm">Delete</button>
            <button type="button" onClick={() => { OnEdit(k) }} className="btn btn-outline-success btn-sm ms-1">Edit</button>
          </td>
            </tr>;
           })}
           </tbody>
           
         
    
          
   
      </table>
     
  );
}
export function Hotels()
{
  const OnClick=()=>
  {
    window.location.href="/AddHotelDetail";
  }
  return(
    <div>
      
      <button onClick={OnClick} className="btn btn-primary ms-4">Add New Hotel</button>
      <PostHotels/>
    </div>
  );
}