import {useRef,useState,useEffect} from "react";
import axios from "axios";
import { useLocation, useNavigate } from 'react-router-dom';
function AddBookingDetail()
{
    let location = useLocation();
    let navigate = useNavigate();
    const roomId=useRef();
    const userId=useRef();
    const checkinDate=useRef();
    const checkoutDate=useRef();
    const bookingPrice=useRef();
    const bookingDate=useRef();
    const IntitalBookingDetails={roomId:"", userId:"",checkinDate:"",checkoutDate:"",bookingPrice:"",bookingDate:""};
    const [bookingdetails, setBookingDetails] = useState(IntitalBookingDetails);
    function onSubmitClick()
    {
       alert(`Room Id: ${roomId} User Id: ${userId} CheckinDate: ${checkinDate} CheckoutDate: ${checkoutDate} Booking Price: ${bookingPrice} Booking Date:${bookingDate}`);
    }
    function handleOnBookingDetailChange(e) {
        let { name, value } = e.target;
        setBookingDetails((prevstate) => {
            return ({ ...prevstate, [name]: value })
        })

    }
    function OnAddNewBooking() {
        axios.post('https://localhost:44328/api/Booking', bookingdetails)
            .then((response) => {
                alert('New Booking added succesfully');
                setBookingDetails(IntitalBookingDetails);
            })
            .catch((err) => { alert('Failed to add new booking') })
    }
    useEffect(() => {


        if (Boolean(location.state)) {
            setBookingDetails(location.state);

        }



    }, [location])
    function OnUpdateBooking() {
        axios.put('https://localhost:44328/api/Booking/Update', bookingdetails)
            .then((response) => {
                alert(' bookings Updated succesfully');
                navigate('/Bookings');
            })
            .catch((err) => { alert('Failed to update booking') })
    }
    return(
        <div>
            <h2>Booking Details Details</h2>
            <form onSubmit={onSubmitClick}>
                <label name="roomId">Enter Room Id</label>
                <input type="text" name="roomId"  onChange={handleOnBookingDetailChange} ref={roomId} value={bookingdetails.roomId}/>
                <br/>
                <br/>
                <label name="userId">Enter User Id</label>
                <input type="text" name="userId" onChange={handleOnBookingDetailChange} ref={userId} value={bookingdetails.userId}/>
                <br/>
                <br/>
                <label name="checkinDate">Enter In date</label>
                <input type="datetime-local" name="checkinDate" onChange={handleOnBookingDetailChange} ref={checkinDate} value={bookingdetails.checkinDate}/>
                <br/>
                <br/>
                <label name="checkoutDate">Enter Out date</label>
                <input type="datetime-local" name="checkoutDate" onChange={handleOnBookingDetailChange}  ref={checkoutDate} value={bookingdetails.checkoutDate}/>
                <br/>
                <br/>
                <label name="bookingPrice">Enter Booking price</label>
                <input type="text" name="bookingPrice" onChange={handleOnBookingDetailChange} ref={bookingPrice} value={bookingdetails.bookingPrice}/>
                <br/>
                <br/>
                <label name="bookingDate">Enter Booking date</label>
                <input type="datetime-local" name="bookingDate" onChange={handleOnBookingDetailChange} ref={bookingDate} value={bookingdetails.bookingDate}/>
                <br/>
                <br/>
                {Boolean(location.state)
                    ? <button type="button" onClick={OnUpdateBooking} className="btn btn-primary">Update</button>
                    : <button type="button" onClick={OnAddNewBooking} className="btn btn-primary">Add Booking</button>
                }
            </form>
        </div>
    );
}
export default AddBookingDetail;