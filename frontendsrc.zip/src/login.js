import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios';

function Login() {
  const [email, setemail] = useState("");
  const [password, setpassword] = useState("");
  const [PwtVisibility, setPwtVisibility] = useState(false);
  let navigate = useNavigate();


  async function login() {
    // if(.)
    // {
    //    navigate('/Home');
    // }
    // else{
    //   alert(`Invalid Login`);
    // }
    axios.post('https://localhost:44328/api/User/LoginUser', { UserEmail: email, password })
      .then((response) => {
        navigate('/Home');
        localStorage.setItem('IsLoggedIn', true);
        localStorage.setItem('UserDetails', JSON.stringify(response));
      })
      .catch((err) => { alert('Invalid Login') })
 





  }
  return (
    <div className='vh-100 d-flex align-items-center'>
    <div className='col-sm-4 offset-sm-3'>
      <h1>login page</h1>
      <input type="text" value={email} onChange={(e) => setemail(e.target.value)} placeholder='email' className="form-control" />
      <br>
      </br>
      <input type={PwtVisibility ? "text" : "password"} value={password} onChange={(e) => setpassword(e.target.value)} placeholder='password' className="form-control" />
      
      <div className="form-check mt-1">
        <input className="form-check-input" type="checkbox" name="roomAvailable" onChange={() => { setPwtVisibility(!PwtVisibility) }} checked={PwtVisibility} />
        <label className="form-check-label">
         
          Show Password
        </label>

      </div>
      <br></br>

      <button type='button' onClick={login} className='btn btn-primary'>Login</button>
      <p>Dont have an account? <a href="/signupform"> Signup </a></p>
    </div>
    </div>
    

  )
}

export default Login