import { React, useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'
export function PostRooms() {
  const [rooms, setrooms] = useState([]);
  let navigate = useNavigate();


  const getRoom = async () => {
    try {
      const response = await fetch('https://localhost:44328/api/Room/GetRooms');
      const data = await response.json();
      setrooms(data);
      // console.log(data);
    } catch (error) {
      // console.log(error);
      alert(`failed to load rooms`);
    }
  };
  useEffect(() => {
    getRoom();
  }, [])

  function OnDelete(id) {
    axios.delete("https://localhost:44328/api/Room/Delete/" + id)
      .then((response) => {
        alert(' room deleted succesfully');
        getRoom();

      })
      .catch((err) => { alert('Failed to delete room') })
  }

  function OnEdit(p) {
    navigate('/AddRoomDetail', { state: p });



  }


  return (

    <table border='2' className="table-light w-75  m-4 ">
      <span className="border border-dark"></span>
      <thead className="table-success" align="center">
      <tr>
        <th colSpan={10}>Room Details</th>
      </tr>
     
      <tr>
        <th>Sno</th>
        <th className="p-1">RoomId</th>
        <th className="p-1">HotelId</th>
        <th className="p-1">RoomType</th>
        <th className="p-1">RoomPrice</th>
        <th className="p-1">RoomCapacity</th>
        <th className="p-1">RoomAvailable</th>
        <th className="p-1">Action</th>




      </tr>
      </thead>
      <tbody>
      {rooms.map((p, i) => {
        return <tr className="table-light" key={i} value={p}>
          <td>{i + 1}</td>

          <td className="p-1">{p.roomId}</td>
          <td className="p-1">{p.hotelId}</td>
          <td className="p-1">{p.roomType}</td>
          <td className="p-1">{p.roomPrice}</td>
          <td className="p-1">{p.roomCapacity}</td>
          <td className="p-1">{p.roomAvailable ? "yes" : "no"}</td>
          <td className="p-1">
            <button type="button" onClick={() => { OnDelete(p.roomId) }} className="btn btn-outline-danger btn-sm">Delete</button>
            <button type="button" onClick={() => { OnEdit(p) }} className="btn btn-outline-success btn-sm">Edit</button>
          </td>


        </tr>;
      })}
      </tbody>





    </table>

  );
}
export function Rooms() {
  const OnClick = () => {
    window.location.href = "/AddRoomDetail";
  }
  return (
    <div>

      <button onClick={OnClick} className="btn btn-primary ms-4">Add New Room</button>
      <PostRooms />
    </div>
  );
}