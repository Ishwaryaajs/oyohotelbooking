import { React, useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
export function PostBookings() {
  const [bookings, setbookings] = useState([]);

  let navigate = useNavigate();


  const getBooking = async () => {
    try {
      const response = await fetch('https://localhost:44328/api/Booking/GetBookings');
      const data = await response.json();
      setbookings(data);
      // console.log(data);
    } catch (error) {
      // console.log(error);
      alert(`failed to load bookings`);
    }
  };
  useEffect(() => {
    getBooking();
  }, [])
  function OnDelete(id) {
    axios.delete("https://localhost:44328/api/Booking/Delete/" + id)
      .then((response) => {
        alert(' Bookings deleted succesfully');
        getBooking();

      })
      .catch((err) => { alert('Failed to delete booking') })

  }
  function OnEdit(b) {
    navigate('/AddBookingDetail', { state: b });



  }



  return (

    <table border='2' className="table table-light w-75  m-4">
      <span className="border border-dark"></span>
      <thead className="table-success" align="center">
      <tr>
        <th colSpan={10}>Booking Details</th>
      </tr>
      
      <tr>

        <th className='p-1'>BookingId</th>
        <th className='p-1'>UserId</th>
        <th className='p-1'>UserName</th>
        <th className='p-1'>RoomId</th>
        <th className='p-1'>CheckinDate</th>
        <th className='p-1'>CheckOutDate</th>
        <th className='p-1'>Booking Price</th>
        <th className='p-1'>Booking Date</th>
        <th className='p-1'>Action</th>


      </tr>
      </thead>
      <tbody>
      {bookings.map((b, j) => {
        return <tr key={j} value={b}>

          <td className='p-1'>{b.bookingId}</td>
          <td className='p-1'>{b.userId}</td>
          <td className='p-1'>{b.userName}</td>
          <td className='p-1'>{b.roomId}</td>
          <td className='p-1'>{new Date(b.checkinDate).toLocaleDateString()}</td>
          <td className='p-1'>{new Date(b.checkoutDate).toLocaleDateString()}</td>
          <td className='p-1'>{b.bookingPrice}</td>
          <td className='p-1'>{new Date(b.bookingDate).toLocaleDateString()}</td>
          <td className='p-1'>
            <button type="button" onClick={() => { OnDelete(b.bookingId) }} className="btn btn-outline-danger btn-sm">Delete</button>
            <button type="button" onClick={() => { OnEdit(b) }} className="btn btn-outline-success btn-sm">Edit</button>
          </td>

        </tr>;
      })}
      </tbody>





    </table>

  );
}
export function Bookings() {
  const OnClick = () => {
    window.location.href = "/AddBookingDetail";
  }
  return (
    <div>

      <button onClick={OnClick} className="btn btn-primary ms-4">Add New Booking</button>
      <PostBookings />
    </div>
  );
}